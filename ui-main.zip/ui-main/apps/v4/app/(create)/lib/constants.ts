export const ALLOWED_ITEM_TYPES = ["registry:block", "registry:example"]
