export const showMcpDocs = true
